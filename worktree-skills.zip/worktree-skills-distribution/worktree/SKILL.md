---
name: worktree
description: Create git worktree with Graphite + VSCode + auto Claude session. Use when user wants to create a new worktree for a feature branch.
argument-hint: <branch-name> [base-branch] [subdir]
model: claude-haiku-4-5-20251001
allowed-tools: Bash(*)
---

# Create Git Worktree

**Branch:** $1
**Base (if new):** ${2:-main}
**Subdir (optional):** $3 - Subdirectory relative to repo root for working directory (e.g., "ai-platform")

## Step 1: Find Workspace File and Check Existing Emojis

First, find the workspace file and check what emojis are already in use.

Run this command to find the workspace file:
```bash
find "$(git rev-parse --show-toplevel)" "$(git rev-parse --show-toplevel)/.." -maxdepth 1 -name "*.code-workspace" 2>/dev/null | head -1
```

Then check existing emojis (replace WORKSPACE_FILE with the path from above, or skip if no workspace found):
```bash
cat "WORKSPACE_FILE_PATH" | grep -o '🌳[^ ]*' | sort -u
```

Parse the output to extract emojis that follow the 🌳 (tree) prefix. If no emojis are found, all are available.

## Step 2: Pick Contextual Emoji

Analyze the branch name `$1` and pick ONE relevant emoji that is **NOT** already in use (from Step 1).

**Expanded emoji palette (grouped by category):**

**Development & Code:**
- feat/feature → ✨ (sparkles) | 🎁 (gift) | 🌟 (star) | 💫 (dizzy)
- fix/bug → 🐛 (bug) | 🔧 (wrench) | 🩹 (bandage) | 🛠️ (hammer/wrench)
- refactor/clean → ♻️ (recycle) | 🧹 (broom) | 🧼 (soap) | 🗜️ (clamp)
- test/testing → 🧪 (test tube) | 🔬 (microscope) | ✅ (check) | 🎯 (target)
- perf/performance → ⚡ (zap) | 🏃 (runner) | 🚄 (bullet train) | 💨 (dash)

**Documentation & Content:**
- docs/documentation → 📝 (memo) | 📚 (books) | 📖 (book) | 📄 (page)
- slide/presentation → 📽️ (projector) | 🎞️ (film) | 🖼️ (frame) | 🎬 (clapper)

**Infrastructure & Config:**
- build/deploy → 🚀 (rocket) | 🏗️ (construction) | 📦 (package) | 🎉 (party)
- config/settings → ⚙️ (gear) | 🔩 (nut/bolt) | 🎛️ (control knobs) | 🔑 (key)
- migration → 🚚 (truck) | 🔀 (shuffle) | 📮 (postbox) | 🗺️ (map)

**Security & Auth:**
- security/auth → 🔒 (lock) | 🛡️ (shield) | 🔐 (locked key) | 🗝️ (key)

**Data & Storage:**
- database/db → 🗄️ (file cabinet) | 💾 (floppy) | 💿 (cd) | 🗃️ (card file)
- firebase/firestore → 🔥 (fire) | 🌋 (volcano) | 💥 (explosion) | 🎆 (fireworks)
- cache/redis → 💾 (floppy) | 🗂️ (dividers) | 📇 (index) | 🧊 (ice)

**API & Integration:**
- api/endpoint → 🔌 (plug) | 🔗 (link) | 🌐 (globe) | 🛰️ (satellite)
- socket/realtime → 🔗 (link) | ⚡ (zap) | 📡 (antenna) | 🌊 (wave)
- webhook → 🪝 (hook) | 📬 (mailbox) | 📨 (incoming) | 🎣 (fishing)

**UI & Design:**
- ui/ux/design → 🎨 (palette) | 🖌️ (paintbrush) | 🎭 (masks) | 🌈 (rainbow)
- style/css → 💅 (nail polish) | 🎀 (ribbon) | ✨ (sparkles) | 🦋 (butterfly)

**Features & Content Types:**
- calculator/math → 🧮 (abacus) | ➕ (plus) | 📐 (triangle ruler) | 🔢 (numbers)
- video/media → 🎥 (camera) | 📹 (video camera) | 🎬 (clapper) | 📺 (tv)
- audio/music → 🎵 (note) | 🎧 (headphones) | 🎙️ (microphone) | 🔊 (speaker)
- image/photo → 🖼️ (frame) | 📷 (camera) | 🌄 (sunrise) | 🎨 (palette)
- graph/chart → 📊 (chart) | 📈 (trending) | 📉 (declining) | 🗠 (graph)
- artifact → 🏺 (amphora) | 📜 (scroll) | 🗿 (moai) | 💎 (gem)

**Communication & Notifications:**
- email/notification → 📧 (email) | 📬 (mailbox) | 🔔 (bell) | 📮 (postbox)
- chat/message → 💬 (speech) | 💭 (thought) | 🗨️ (message) | 📢 (loudspeaker)

**User & Account:**
- user/account → 👤 (person) | 👥 (people) | 🧑 (person) | 👨‍💼 (businessperson)
- profile → 🎭 (masks) | 🃏 (joker) | 🏷️ (label) | 📛 (name badge)

**Business & Analytics:**
- analytics → 📈 (trending) | 📊 (bar chart) | 🔍 (magnifying) | 🎯 (target)
- payment/billing → 💳 (credit card) | 💰 (money bag) | 💵 (dollar) | 🏦 (bank)
- search/query → 🔍 (magnifying) | 🔎 (magnifying right) | 🕵️ (detective) | 🧭 (compass)

**Operations & Utilities:**
- cleanup/remove → 🧹 (broom) | 🗑️ (trash) | 🧽 (sponge) | 🚮 (litter)
- upgrade/update → ⬆️ (up arrow) | 🔝 (top) | ⏫ (double up) | 🆙 (up button)
- download/export → 📥 (inbox) | ⬇️ (down arrow) | 💾 (save) | 📤 (outbox)
- upload/import → 📤 (outbox) | ⬆️ (up arrow) | 📨 (incoming) | 📬 (mailbox)
- monitoring → 👀 (eyes) | 📡 (antenna) | 🔭 (telescope) | 👁️ (eye)
- logging → 📋 (clipboard) | 📝 (memo) | 🗒️ (spiral notepad) | 📊 (chart)

**CORS/Networking:**
- cors → 🌐 (globe) | 🔓 (open lock) | 🌍 (earth) | 🛰️ (satellite)
- network → 🕸️ (spider web) | 🌐 (globe) | 📡 (antenna) | 🔗 (link)

**Dashboards & Monitoring:**
- dashboard/dash → 📊 (bar chart) | 🎛️ (control knobs) | 🖥️ (desktop) | 📺 (tv)
- datadog → 🐕 (dog) | 🦮 (guide dog) | 🐶 (puppy) | 📊 (chart)

**Fallback shapes (if no contextual match):**
🔵 🟢 🟡 🟣 🟠 🔶 🔷 ⭐ 🌙 ☀️ 💠

**Selection strategy:**
1. Find contextual matches for the branch name
2. Filter out emojis already in use (from Step 1)
3. Pick the first available emoji from the relevant category
4. If all contextual emojis are taken, use a fallback shape

Store your chosen emoji (just the emoji character, no spaces).

## Step 3: Run the Script

Execute the worktree creation script with your chosen emoji (and optional subdir):

```bash
~/.claude/skills/worktree/scripts/create-worktree.sh "$1" "${2:-main}" "YOUR_EMOJI" "${3:-}"
```

Replace `YOUR_EMOJI` with the emoji you picked (e.g., `✨` or `🐛`).

If a subdir was provided ($3), it will be used as the working directory for Claude and tmux sessions.

## Step 4: Format Output

Parse the JSON output and display a formatted summary:

```
┌─────────────────────────────────────────────────────────────────┐
│  WORKTREE CREATED                                               │
├─────────────────────────────────────────────────────────────────┤
│  Location:  [worktree_path from JSON]                           │
│  Work Dir:  [work_dir from JSON - shown if subdir was used]     │
│  Branch:    [branch] [NEW from base / EXISTING]                 │
├─────────────────────────────────────────────────────────────────┤
│  Dependencies:  [installed / failed]                            │
│  Env Files:     [list from JSON]                                │
│  Git Exclude:   [configured]                                    │
│  Graphite:      [tracked / skipped]                             │
│  Tasks:         [created - s/c/t with unique group]             │
│  VSCode:        [workspace_name from JSON]                      │
├─────────────────────────────────────────────────────────────────┤
│  CLIPBOARD: Resume command copied!                              │
│  cd + claude --resume (continue session)                        │
├─────────────────────────────────────────────────────────────────┤
│  WORKFLOW:                                                      │
│  Option A - Via Tasks (Recommended):                            │
│    Cmd+Shift+P → Run Task → "s"                                 │
│                                                                 │
│  Option B - Via Clipboard:                                      │
│    Paste in new terminal                                        │
└─────────────────────────────────────────────────────────────────┘
```

If there are warnings in the JSON, list them after the table.

## Examples

```bash
# New feature branch (creates from main)
/wt my-new-feature

# New feature from specific base
/wt my-feature develop

# Existing PR/remote branch
/wt fix-calculator-bug

# New feature with subdirectory as working directory
/wt my-api-feature main ai-platform
```
