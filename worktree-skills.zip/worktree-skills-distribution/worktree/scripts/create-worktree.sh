#!/bin/bash
set -e

# Create Git Worktree with all setup
# Usage: create-worktree.sh <branch> [base] [emoji] [subdir]
# Output: JSON status for LLM to format
#
# Auto-detects project root from current directory
# Optional subdir parameter sets working directory relative to repo root (e.g., "ai-platform")

BRANCH="$1"
BASE="${2:-main}"
EMOJI="${3:-}"
SUBDIR="${4:-}"  # Optional subdirectory relative to repo root

# Display name for notifications/workspace (e.g., "🌳✨ feat-thing")
WORKTREE_DISPLAY_NAME="🌳${EMOJI:+$EMOJI }$BRANCH"

# Auto-detect project root (git root of current directory)
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
if [[ -z "$PROJECT_ROOT" ]]; then
    echo '{"error": "Not in a git repository"}'
    exit 1
fi

PROJECT_NAME=$(basename "$PROJECT_ROOT")
WORKTREE_DIR="${PROJECT_ROOT}-wt"
WORKTREE_PATH="${WORKTREE_DIR}/${BRANCH}"

# Find workspace file dynamically
# Uses most recently modified .code-workspace file in repo root or parent
WORKSPACE_FILE=""
for search_dir in "$PROJECT_ROOT" "${PROJECT_ROOT}/.."; do
    # Find most recently modified workspace file
    found=$(find "$search_dir" -maxdepth 1 -name "*.code-workspace" -print0 2>/dev/null | xargs -0 ls -t 2>/dev/null | head -1)
    if [[ -n "$found" && -f "$found" ]]; then
        WORKSPACE_FILE="$found"
        break
    fi
done

# Status tracking
STATUS="{}"
WARNINGS=()
BRANCH_TYPE="new"

# Helper: Update status JSON
update_status() {
    STATUS=$(echo "$STATUS" | jq --arg key "$1" --arg val "$2" '. + {($key): $val}')
}

# Helper: Add warning
add_warning() {
    WARNINGS+=("$1")
}

# Output final JSON
output_json() {
    local warnings_json
    warnings_json=$(printf '%s\n' "${WARNINGS[@]}" | jq -R . | jq -s .)
    echo "$STATUS" | jq --argjson warnings "$warnings_json" '. + {warnings: $warnings}'
}

# Pre-flight check: Create worktree directory if needed
mkdir -p "$WORKTREE_DIR"

# Pre-flight check: Worktree doesn't exist
if [[ -d "$WORKTREE_PATH" ]]; then
    echo '{"error": "Worktree already exists", "path": "'"$WORKTREE_PATH"'"}'
    exit 1
fi

# Check branch existence
git fetch origin "$BRANCH" 2>/dev/null || true

REMOTE_EXISTS=false
LOCAL_EXISTS=false

if git rev-parse --verify "origin/$BRANCH" 2>/dev/null; then
    REMOTE_EXISTS=true
    BRANCH_TYPE="remote"
fi

if git rev-parse --verify "$BRANCH" 2>/dev/null; then
    LOCAL_EXISTS=true
    BRANCH_TYPE="local"
fi

update_status "branch" "$BRANCH"
update_status "base" "$BASE"
update_status "branch_type" "$BRANCH_TYPE"
update_status "project" "$PROJECT_NAME"

# Step 1: Create worktree
if [[ "$REMOTE_EXISTS" == "true" ]]; then
    # Remote branch exists - check it out
    if ! git worktree add "$WORKTREE_PATH" "$BRANCH" --track -b "$BRANCH" "origin/$BRANCH" 2>/dev/null; then
        git worktree add "$WORKTREE_PATH" "$BRANCH" 2>/dev/null || {
            echo '{"error": "Failed to create worktree from remote branch"}'
            exit 1
        }
    fi
    update_status "worktree" "created_from_remote"
elif [[ "$LOCAL_EXISTS" == "true" ]]; then
    # Local branch exists
    git worktree add "$WORKTREE_PATH" "$BRANCH" || {
        echo '{"error": "Failed to create worktree from local branch"}'
        exit 1
    }
    update_status "worktree" "created_from_local"
else
    # New branch
    git worktree add "$WORKTREE_PATH" -b "$BRANCH" "origin/$BASE" || {
        echo '{"error": "Failed to create new worktree", "base": "'"$BASE"'"}'
        exit 1
    }
    update_status "worktree" "created_new"
fi

update_status "worktree_path" "$WORKTREE_PATH"

# Set working directory (with optional subdirectory)
if [[ -n "$SUBDIR" ]]; then
    WORK_DIR="$WORKTREE_PATH/$SUBDIR"
    if [[ ! -d "$WORK_DIR" ]]; then
        add_warning "Subdirectory '$SUBDIR' does not exist in worktree"
        WORK_DIR="$WORKTREE_PATH"
    else
        update_status "subdir" "$SUBDIR"
    fi
else
    WORK_DIR="$WORKTREE_PATH"
fi

# Step 2: Install dependencies (if pnpm project) - always from worktree root
cd "$WORKTREE_PATH"
if [[ -f "pnpm-lock.yaml" ]]; then
    if pnpm install --prefer-offline 2>/dev/null; then
        update_status "dependencies" "installed"
    else
        add_warning "pnpm install failed"
        update_status "dependencies" "failed"
    fi
elif [[ -f "package-lock.json" ]]; then
    if npm install 2>/dev/null; then
        update_status "dependencies" "installed"
    else
        add_warning "npm install failed"
        update_status "dependencies" "failed"
    fi
else
    update_status "dependencies" "no_lockfile"
fi

# Step 3: Copy env files from package directories
ENV_COPIED=()

while IFS= read -r -d '' pkg_json; do
    pkg_dir=$(dirname "$pkg_json")
    rel_dir="${pkg_dir#$PROJECT_ROOT/}"
    [[ "$rel_dir" == "$pkg_dir" ]] && rel_dir=""

    for env_file in "$pkg_dir"/.env*; do
        [[ -f "$env_file" ]] || continue
        filename=$(basename "$env_file")
        target_dir="$WORKTREE_PATH/$rel_dir"

        if [[ -d "$target_dir" ]]; then
            cp "$env_file" "$target_dir/$filename" && ENV_COPIED+=("${rel_dir:+$rel_dir/}$filename")
        fi
    done
done < <(find "$PROJECT_ROOT" -name "package.json" -type f -not -path "*/node_modules/*" -print0 2>/dev/null)

if [[ ${#ENV_COPIED[@]} -gt 0 ]]; then
    update_status "env_files" "$(IFS=,; echo "${ENV_COPIED[*]}")"
else
    update_status "env_files" "none"
fi

# Step 4: Git exclude setup (always at worktree root)
cd "$WORKTREE_PATH"
# Use --git-common-dir for exclude file (worktrees share the main repo's info/exclude)
GIT_COMMON_DIR=$(git rev-parse --git-common-dir)
mkdir -p "$GIT_COMMON_DIR/info"

# Add patterns to exclude file if not already present
for pattern in ".vscode/" ".mcp.json" ".env*"; do
    grep -qxF "$pattern" "$GIT_COMMON_DIR/info/exclude" 2>/dev/null || echo "$pattern" >> "$GIT_COMMON_DIR/info/exclude"
done

# Skip worktree for tracked .vscode files
git ls-files .vscode/ 2>/dev/null | xargs -I {} git update-index --skip-worktree {} 2>/dev/null || true

# Skip worktree for copied env files (they're tracked, so exclude patterns don't help)
for env_file in "${ENV_COPIED[@]}"; do
    git ls-files "$env_file" 2>/dev/null | xargs -I {} git update-index --skip-worktree {} 2>/dev/null || true
done

update_status "git_exclude" "configured"
update_status "work_dir" "$WORK_DIR"

# Step 4.5: Copy .mcp.json and add Playwright isolation
if [[ -f "$PROJECT_ROOT/.mcp.json" ]]; then
  # Copy main repo's .mcp.json
  cp "$PROJECT_ROOT/.mcp.json" "$WORKTREE_PATH/.mcp.json"

  # Add Playwright with isolated user-data-dir using jq
  if command -v jq &> /dev/null; then
    jq --arg branch "$BRANCH" \
      '.mcpServers.playwright = {
        "command": "npx",
        "args": ["@playwright/mcp@latest", "--user-data-dir=/tmp/pw-\($branch)"]
      }' \
      "$WORKTREE_PATH/.mcp.json" > "$WORKTREE_PATH/.mcp.json.tmp" && \
    mv "$WORKTREE_PATH/.mcp.json.tmp" "$WORKTREE_PATH/.mcp.json"
  else
    # Fallback: warn if jq not available
    add_warning "jq not installed, could not add Playwright isolation to .mcp.json"
  fi

  update_status "mcp_json" "copied_and_modified"
else
  # No .mcp.json in main repo, create minimal one
  cat > "$WORKTREE_PATH/.mcp.json" << MCPEOF
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": [
        "@playwright/mcp@latest",
        "--user-data-dir=/tmp/pw-$BRANCH"
      ]
    }
  }
}
MCPEOF
  update_status "mcp_json" "created_minimal"
fi

# Step 5: Create VSCode tasks.json (in worktree root, but CWD points to work_dir)
mkdir -p "$WORKTREE_PATH/.vscode"
cat > "$WORKTREE_PATH/.vscode/tasks.json" << 'TASKEOF'
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "s",
      "icon": { "id": "play-circle" },
      "color": "terminal.ansiYellow",
      "dependsOn": ["t", "c"],
      "dependsOrder": "parallel",
      "problemMatcher": []
    },
    {
      "label": "c",
      "icon": { "id": "hubot" },
      "color": "terminal.ansiCyan",
      "type": "shell",
      "command": "CLAUDE_WORKTREE='WORKTREE_NAME_PLACEHOLDER' claude --dangerously-skip-permissions --resume BRANCH_PLACEHOLDER || CLAUDE_WORKTREE='WORKTREE_NAME_PLACEHOLDER' claude --dangerously-skip-permissions",
      "isBackground": true,
      "options": {
        "cwd": "CWD_PLACEHOLDER",
        "env": {
          "PATH": "${env:HOME}/.local/bin:${env:PATH}"
        }
      },
      "problemMatcher": {
        "pattern": { "regexp": "^$" },
        "background": {
          "activeOnStart": true,
          "beginsPattern": ".",
          "endsPattern": "Resume Session|How can I help"
        }
      },
      "presentation": {
        "reveal": "always",
        "panel": "dedicated",
        "group": "GROUP_PLACEHOLDER",
        "echo": false,
        "showReuseMessage": false
      }
    },
    {
      "label": "t",
      "icon": { "id": "terminal-bash" },
      "color": "terminal.ansiGreen",
      "type": "shell",
      "command": "tmux new-session -A -s wt-BRANCH_PLACEHOLDER -c 'CWD_PLACEHOLDER'",
      "isBackground": true,
      "options": {
        "cwd": "CWD_PLACEHOLDER"
      },
      "problemMatcher": {
        "pattern": { "regexp": "^$" },
        "background": {
          "activeOnStart": true,
          "beginsPattern": ".",
          "endsPattern": "attached|new-session|\\[wt-"
        }
      },
      "presentation": {
        "reveal": "always",
        "panel": "dedicated",
        "group": "GROUP_PLACEHOLDER",
        "echo": false,
        "showReuseMessage": false
      }
    }
  ]
}
TASKEOF

# Replace placeholders (tasks.json is at worktree root, CWD points to work_dir which may be a subdirectory)
sed -i '' "s|BRANCH_PLACEHOLDER|$BRANCH|g" "$WORKTREE_PATH/.vscode/tasks.json"
sed -i '' "s|CWD_PLACEHOLDER|$WORK_DIR|g" "$WORKTREE_PATH/.vscode/tasks.json"
sed -i '' "s|GROUP_PLACEHOLDER|wt-$BRANCH|g" "$WORKTREE_PATH/.vscode/tasks.json"
sed -i '' "s|WORKTREE_NAME_PLACEHOLDER|$WORKTREE_DISPLAY_NAME|g" "$WORKTREE_PATH/.vscode/tasks.json"

update_status "tasks_json" "created"

# Step 6: Update workspace file with name (create if doesn't exist)
# NOTE: We do NOT use `code --add` because it creates a race condition where
# VSCode overwrites our changes. The Python script handles everything.
# Always add/update the folder entry - don't rely on `code --add`

# If no workspace file exists, create one
if [[ -z "$WORKSPACE_FILE" || ! -f "$WORKSPACE_FILE" ]]; then
    WORKSPACE_FILE="$PROJECT_ROOT/$PROJECT_NAME.code-workspace"
    echo '{"folders": []}' > "$WORKSPACE_FILE"
fi

python3 << PYEOF
import json
import sys
import os

workspace_file = "$WORKSPACE_FILE"
worktree_path = "$WORKTREE_PATH"
display_name = "$WORKTREE_DISPLAY_NAME"

try:
    with open(workspace_file, 'r') as f:
        workspace = json.load(f)

    # Normalize paths for comparison
    worktree_abs = os.path.abspath(worktree_path)
    workspace_dir = os.path.dirname(os.path.abspath(workspace_file))

    # Calculate relative path from workspace file to worktree
    relative_path = os.path.relpath(worktree_abs, workspace_dir)

    # Search for existing folder entry
    found = False
    for folder in workspace.get('folders', []):
        path = folder.get('path', '')
        folder_abs = os.path.abspath(os.path.join(workspace_dir, path))
        if folder_abs == worktree_abs or path.endswith(os.path.basename(worktree_path)):
            folder['name'] = display_name
            found = True
            break

    # If not found, add it (code --add may have failed silently)
    if not found:
        if 'folders' not in workspace:
            workspace['folders'] = []
        workspace['folders'].append({
            'name': display_name,
            'path': relative_path
        })

    with open(workspace_file, 'w') as f:
        json.dump(workspace, f, indent=2)

    print("updated" if found else "added")
except Exception as e:
    print(f"error: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF
if [[ $? -eq 0 ]]; then
    update_status "workspace_name" "$WORKTREE_DISPLAY_NAME"
    update_status "workspace_file" "$WORKSPACE_FILE"
else
    add_warning "Failed to update workspace name"
    update_status "workspace_name" "not_set"
fi

# Step 8: Copy resume command to clipboard (uses WORK_DIR which may include subdirectory)
echo "cd '$WORK_DIR' && claude --resume $BRANCH" | pbcopy

update_status "clipboard" "resume_command_copied"

# Step 9: Track branch with Graphite
cd "$WORKTREE_PATH"
if command -v gt &> /dev/null; then
    if gt track "$BASE" 2>/dev/null; then
        update_status "graphite" "tracked"
    else
        # Likely already tracked or repo not initialized with gt
        update_status "graphite" "skipped"
        add_warning "Graphite tracking skipped (may already be tracked or gt not initialized)"
    fi
else
    update_status "graphite" "not_installed"
fi

# Output final status
cd "$PROJECT_ROOT"
output_json
