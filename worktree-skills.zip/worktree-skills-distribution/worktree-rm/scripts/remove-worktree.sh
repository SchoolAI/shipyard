#!/bin/bash
set -e

# Remove Git Worktree with safety checks
# Usage: remove-worktree.sh <branch> --check|--remove [--force]
# Output: JSON status
#
# Auto-detects worktree path from `git worktree list` - works with any path structure

BRANCH="$1"
MODE="$2"
FORCE="$3"

if [[ -z "$BRANCH" || -z "$MODE" ]]; then
    echo '{"error": "Usage: remove-worktree.sh <branch> --check|--remove [--force]"}'
    exit 1
fi

# Auto-detect project root
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
if [[ -z "$PROJECT_ROOT" ]]; then
    echo '{"error": "Not in a git repository"}'
    exit 1
fi

# Find workspace file dynamically
# Uses most recently modified .code-workspace file in repo root or parent
WORKSPACE_FILE=""
for search_dir in "$PROJECT_ROOT" "${PROJECT_ROOT}/.."; do
    # Find most recently modified workspace file
    found=$(find "$search_dir" -maxdepth 1 -name "*.code-workspace" -print0 2>/dev/null | xargs -0 ls -t 2>/dev/null | head -1)
    if [[ -n "$found" && -f "$found" ]]; then
        WORKSPACE_FILE="$found"
        break
    fi
done

# Helper: Find worktree path from git worktree list
# This is the KEY FIX - we detect the actual path instead of assuming
find_worktree_path() {
    local search_branch="$1"
    # Try exact branch match first
    local path=$(git worktree list --porcelain | grep -A2 "^worktree " | while read -r line; do
        if [[ "$line" =~ ^worktree\ (.*) ]]; then
            current_path="${BASH_REMATCH[1]}"
        elif [[ "$line" =~ ^branch\ refs/heads/(.*) ]]; then
            if [[ "${BASH_REMATCH[1]}" == "$search_branch" ]]; then
                echo "$current_path"
                break
            fi
        fi
    done)

    if [[ -n "$path" ]]; then
        echo "$path"
        return 0
    fi

    # Fallback: search by path containing branch name
    git worktree list | while read -r wt_line; do
        local wt_path=$(echo "$wt_line" | awk '{print $1}')
        if [[ "$wt_path" == *"$search_branch"* ]]; then
            echo "$wt_path"
            break
        fi
    done
}

# Helper: Output JSON
output_json() {
    echo "$1"
}

# MODE: --check
if [[ "$MODE" == "--check" ]]; then
    STATUS='{}'

    # Check 0: Not inside worktree being removed
    CURRENT_DIR=$(pwd)
    if [[ "$CURRENT_DIR" == *"$BRANCH"* ]]; then
        echo '{"error": "Cannot remove worktree while inside it!", "current_dir": "'"$CURRENT_DIR"'", "action": "cd to main project directory first"}'
        exit 1
    fi
    STATUS=$(echo "$STATUS" | jq '.current_dir = "safe"')

    # Check 1: Find worktree path
    WORKTREE_PATH=$(find_worktree_path "$BRANCH")
    if [[ -z "$WORKTREE_PATH" ]] || [[ ! -d "$WORKTREE_PATH" ]]; then
        echo '{"error": "Worktree not found", "branch": "'"$BRANCH"'", "hint": "Run git worktree list to see available worktrees"}'
        exit 1
    fi
    STATUS=$(echo "$STATUS" | jq --arg path "$WORKTREE_PATH" '.worktree_exists = true | .worktree_path = $path')

    # Check 2: Uncommitted changes (excluding .vscode)
    cd "$WORKTREE_PATH"
    CHANGES=$(git status --porcelain | grep -v "^.. .vscode/" || true)
    VSCODE_ONLY=$(git status --porcelain | grep "^.. .vscode/" || true)

    if [[ -n "$CHANGES" ]]; then
        CHANGE_COUNT=$(echo "$CHANGES" | wc -l | tr -d ' ')
        STATUS=$(echo "$STATUS" | jq --arg count "$CHANGE_COUNT" '.uncommitted_changes = ($count | tonumber)')
        STATUS=$(echo "$STATUS" | jq --arg files "$CHANGES" '.uncommitted_files = $files')
    else
        STATUS=$(echo "$STATUS" | jq '.uncommitted_changes = 0')
    fi

    if [[ -n "$VSCODE_ONLY" ]]; then
        STATUS=$(echo "$STATUS" | jq '.vscode_changes_only = true')
    fi

    # Check 3: Unpushed commits
    UNPUSHED=$(git log "origin/$BRANCH..$BRANCH" --oneline 2>/dev/null || echo "")
    if [[ -n "$UNPUSHED" ]]; then
        UNPUSHED_COUNT=$(echo "$UNPUSHED" | wc -l | tr -d ' ')
        STATUS=$(echo "$STATUS" | jq --arg count "$UNPUSHED_COUNT" '.unpushed_commits = ($count | tonumber)')
    else
        STATUS=$(echo "$STATUS" | jq '.unpushed_commits = 0')
    fi

    # Check 4: PR status via GitHub CLI
    GH_PR=$(gh pr list --state all --head "$BRANCH" --json number,state 2>/dev/null | jq -r '.[0] // empty')
    if [[ -n "$GH_PR" ]]; then
        GH_STATE=$(echo "$GH_PR" | jq -r '.state')
        GH_NUM=$(echo "$GH_PR" | jq -r '.number')
        if [[ "$GH_STATE" == "MERGED" ]]; then
            STATUS=$(echo "$STATUS" | jq --arg num "$GH_NUM" '.pr_status = "merged (#\($num))"')
        elif [[ "$GH_STATE" == "OPEN" ]]; then
            STATUS=$(echo "$STATUS" | jq --arg num "$GH_NUM" '.pr_status = "open (#\($num))"')
        else
            STATUS=$(echo "$STATUS" | jq --arg state "$GH_STATE" '.pr_status = $state')
        fi
    else
        STATUS=$(echo "$STATUS" | jq '.pr_status = "not_submitted"')
    fi

    # Check 5: tmux session exists
    if tmux has-session -t "wt-$BRANCH" 2>/dev/null; then
        STATUS=$(echo "$STATUS" | jq '.tmux_session = "active"')
    else
        STATUS=$(echo "$STATUS" | jq '.tmux_session = "none"')
    fi

    # Determine if safe
    UNCOMMITTED=$(echo "$STATUS" | jq -r '.uncommitted_changes // 0')
    UNPUSHED_VAL=$(echo "$STATUS" | jq -r '.unpushed_commits // 0')

    if [[ "$UNCOMMITTED" -eq 0 && "$UNPUSHED_VAL" -eq 0 ]]; then
        STATUS=$(echo "$STATUS" | jq '.safe_to_remove = true')
    elif [[ "$UNCOMMITTED" -eq 0 && "$UNPUSHED_VAL" -eq 0 ]] && echo "$STATUS" | jq -e '.vscode_changes_only == true' > /dev/null 2>&1; then
        STATUS=$(echo "$STATUS" | jq '.safe_to_remove = true')
    else
        STATUS=$(echo "$STATUS" | jq '.safe_to_remove = false')
    fi

    STATUS=$(echo "$STATUS" | jq --arg branch "$BRANCH" '. + {branch: $branch}')

    cd "$PROJECT_ROOT"
    output_json "$STATUS"
    exit 0
fi

# MODE: --remove
if [[ "$MODE" == "--remove" ]]; then
    STATUS='{}'

    # Verify not inside worktree
    CURRENT_DIR=$(pwd)
    if [[ "$CURRENT_DIR" == *"$BRANCH"* ]]; then
        echo '{"error": "Cannot remove worktree while inside it!"}'
        exit 1
    fi

    # Find actual worktree path
    WORKTREE_PATH=$(find_worktree_path "$BRANCH")
    if [[ -z "$WORKTREE_PATH" ]]; then
        # Worktree might already be removed from git, try to find orphaned directory
        WORKTREE_PATH=$(find "${PROJECT_ROOT}/.." -maxdepth 3 -type d -name "*$BRANCH*" 2>/dev/null | head -1)
    fi

    STATUS=$(echo "$STATUS" | jq --arg path "$WORKTREE_PATH" '.worktree_path = $path')

    # Step 1: Remove from VSCode workspace
    if [[ -n "$WORKTREE_PATH" ]]; then
        if code --remove "$WORKTREE_PATH" 2>/dev/null; then
            sleep 2
            STATUS=$(echo "$STATUS" | jq '.vscode_removed = true')
        else
            STATUS=$(echo "$STATUS" | jq '.vscode_removed = false')
        fi
    fi

    # Step 1.5: Also clean up workspace file directly (remove stale entries)
    if [[ -n "$WORKSPACE_FILE" && -f "$WORKSPACE_FILE" ]]; then
        python3 << PYEOF
import json
import sys

workspace_file = "$WORKSPACE_FILE"
branch = "$BRANCH"

try:
    with open(workspace_file, 'r') as f:
        workspace = json.load(f)

    original_count = len(workspace.get('folders', []))
    workspace['folders'] = [
        f for f in workspace.get('folders', [])
        if branch not in f.get('path', '') and branch not in f.get('name', '')
    ]
    new_count = len(workspace['folders'])

    if new_count < original_count:
        with open(workspace_file, 'w') as f:
            json.dump(workspace, f, indent=2)
        print(f"removed {original_count - new_count} entries")
    else:
        print("no entries to remove")
except Exception as e:
    print(f"error: {e}", file=sys.stderr)
PYEOF
        STATUS=$(echo "$STATUS" | jq '.workspace_cleaned = true')
    fi

    # Step 2: Kill tmux session if exists
    if tmux kill-session -t "wt-$BRANCH" 2>/dev/null; then
        STATUS=$(echo "$STATUS" | jq '.tmux_session_killed = true')
    else
        STATUS=$(echo "$STATUS" | jq '.tmux_session_killed = "not_running"')
    fi

    # Step 3: Remove git worktree
    if [[ -n "$WORKTREE_PATH" ]]; then
        if [[ "$FORCE" == "--force" ]]; then
            if git worktree remove --force "$WORKTREE_PATH" 2>/dev/null; then
                STATUS=$(echo "$STATUS" | jq '.worktree_removed = true')
            else
                STATUS=$(echo "$STATUS" | jq '.worktree_removed = false' | jq '.worktree_error = "force removal failed"')
            fi
        else
            if git worktree remove "$WORKTREE_PATH" 2>/dev/null; then
                STATUS=$(echo "$STATUS" | jq '.worktree_removed = true')
            else
                # Try force if normal fails
                if git worktree remove --force "$WORKTREE_PATH" 2>/dev/null; then
                    STATUS=$(echo "$STATUS" | jq '.worktree_removed = true' | jq '.used_force = true')
                else
                    STATUS=$(echo "$STATUS" | jq '.worktree_removed = false' | jq '.worktree_error = "removal failed, may need manual cleanup"')
                fi
            fi
        fi

        # Step 3.5: Clean up directory if it still exists
        if [[ -d "$WORKTREE_PATH" ]]; then
            if rm -rf "$WORKTREE_PATH" 2>/dev/null; then
                STATUS=$(echo "$STATUS" | jq '.directory_cleaned = true')
            else
                STATUS=$(echo "$STATUS" | jq '.directory_cleaned = false')
            fi
        else
            STATUS=$(echo "$STATUS" | jq '.directory_cleaned = "not_needed"')
        fi

        # Step 3.6: Clean up parent directory if empty
        PARENT_DIR=$(dirname "$WORKTREE_PATH")
        if [[ -d "$PARENT_DIR" ]] && [[ -z "$(ls -A "$PARENT_DIR" 2>/dev/null)" ]]; then
            rmdir "$PARENT_DIR" 2>/dev/null && STATUS=$(echo "$STATUS" | jq '.parent_dir_cleaned = true')
        fi
    fi

    # Step 4: Prune worktree references
    git worktree prune 2>/dev/null || true

    # Step 5: Delete branch (check PR status first)
    MERGED_PR=$(gh pr list --state merged --search "$BRANCH" --json number,headRefName --jq ".[] | select(.headRefName == \"$BRANCH\") | .number" 2>/dev/null || echo "")

    if [[ -n "$MERGED_PR" ]]; then
        if git branch -D "$BRANCH" 2>/dev/null; then
            STATUS=$(echo "$STATUS" | jq '.branch_deleted = true' | jq --arg pr "$MERGED_PR" '.branch_deleted_reason = "PR #" + $pr + " was merged"')
        else
            STATUS=$(echo "$STATUS" | jq '.branch_deleted = false' | jq '.branch_kept_reason = "force delete failed"')
        fi
    else
        if git branch -d "$BRANCH" 2>/dev/null; then
            STATUS=$(echo "$STATUS" | jq '.branch_deleted = true')
        else
            STATUS=$(echo "$STATUS" | jq '.branch_deleted = false' | jq '.branch_kept_reason = "unmerged or in use"')
        fi
    fi

    STATUS=$(echo "$STATUS" | jq --arg branch "$BRANCH" '. + {branch: $branch}')

    output_json "$STATUS"
    exit 0
fi

echo '{"error": "Invalid mode. Use --check or --remove"}'
exit 1
