---
name: worktree-rm
description: Safely remove a git worktree with safety checks. Use when user wants to remove/delete a worktree.
argument-hint: <branch-name>
model: claude-haiku-4-5-20251001
allowed-tools: Bash(*)
---

# Remove Git Worktree

**Target Branch:** $1

## Step 1: Run Safety Checks

```bash
~/.claude/skills/worktree-rm/scripts/remove-worktree.sh "$1" --check
```

## Step 2: Interpret Results

Parse the JSON and display a summary:

```
┌─────────────────────────────────────────────────────────────────┐
│  WORKTREE REMOVAL CHECK: [branch from JSON]                     │
├─────────────────────────────────────────────────────────────────┤
│  Path:               [worktree_path from JSON]                  │
│  Current dir:        [SAFE / INSIDE WORKTREE - STOP!]           │
│  Uncommitted changes: [NONE / Only .vscode (OK) / X files]      │
│  Unpushed commits:   [NONE / X commits]                         │
│  PR status:          [MERGED / OPEN / NOT_SUBMITTED]            │
│  Tmux session:       [active / none]                            │
├─────────────────────────────────────────────────────────────────┤
│  [SAFE TO REMOVE / WARNINGS FOUND]                              │
└─────────────────────────────────────────────────────────────────┘
```

## Step 3: Decision Logic

**If error (inside worktree):**
- Stop immediately
- Tell user: "Cannot remove worktree while inside it! cd to main project directory first"

**If safe_to_remove is true:**
- Proceed directly to Step 4

**If safe_to_remove is false:**
- List the specific warnings:
  - Uncommitted changes (list files if any)
  - Unpushed commits (show count)
  - Open PR (mention it)
- Ask user: "Do you want to proceed anyway? (y/n)"
- If user says no, stop
- If user says yes, proceed to Step 4

## Step 4: Execute Removal

```bash
~/.claude/skills/worktree-rm/scripts/remove-worktree.sh "$1" --remove
```

If removal fails, try with force:
```bash
~/.claude/skills/worktree-rm/scripts/remove-worktree.sh "$1" --remove --force
```

## Step 5: Format Output

Parse the JSON and display:

```
┌─────────────────────────────────────────────────────────────────┐
│  WORKTREE REMOVED                                               │
├─────────────────────────────────────────────────────────────────┤
│  VSCode:       [Removed from workspace / Failed]                │
│  Worktree:     [worktree_path] [DELETED / FAILED]               │
│  Branch:       [branch] [DELETED / KEPT - reason]               │
│  Tmux Session: [Killed / Not running]                           │
└─────────────────────────────────────────────────────────────────┘
```

**Branch status display:**
- If `branch_deleted` is true and `branch_deleted_reason` exists: Show reason (e.g., "DELETED - PR #12659 was merged")
- If `branch_deleted` is true without reason: Show "DELETED"
- If `branch_deleted` is false: Show "KEPT - " + `branch_kept_reason`

## Error Recovery

If removal fails midway, provide manual cleanup commands using values from JSON:

```bash
# Manual cleanup commands (use actual paths from JSON):
code --remove "[worktree_path from JSON]"
git worktree remove --force "[worktree_path from JSON]"
git branch -D [branch]  # Force delete branch
```

## Examples

```bash
# Remove a worktree by branch name
/wt-rm my-feature

# Remove a worktree with full branch path
/wt-rm feature/pow-123-some-feature

# After merging a PR
/wt-rm fix-calculator-bug
```
