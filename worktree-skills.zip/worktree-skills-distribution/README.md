# Git Worktree Management Skills for Claude Code

A set of skills that supercharge your git worktree workflow with Claude Code, enabling emoji-tagged worktrees, VSCode integration, and automated project setup.

## What This Is

Three Claude Code skills that make working with git worktrees effortless:

- **`/wt`** - Create new worktree with emoji tagging, VSCode workspace integration, and auto-setup
- **/wt-rm** - Remove worktree safely with cleanup verification
- **/wts** - Show beautiful ASCII dashboard of all worktrees with status

## Features

✨ **Emoji-Tagged Worktrees** - Contextual emoji picked automatically from branch name
📦 **Full Project Setup** - `pnpm install`, env files, git exclude, tasks
🔧 **VSCode Integration** - Auto-adds to workspace file
📊 **Status Dashboard** - See all worktrees, changes, PR status at a glance
🎯 **Smart Branch Detection** - Works with new branches, existing branches, and PRs
📋 **Resume Commands** - Clipboard integration for quick session resumption

## Prerequisites

- **Claude Code** CLI installed and configured
- **Git** worktree support (Git 2.5+)
- **pnpm** package manager (or modify scripts for npm/yarn)
- **gh** CLI (GitHub CLI) for PR status (optional but recommended)
- **jq** for JSON parsing

### Install Prerequisites

```bash
# macOS
brew install gh jq

# Claude Code
# Download from: https://claude.ai/download
```

## Installation

### Option 1: Automated Install (Recommended)

```bash
# Extract the zip file
unzip worktree-skills.zip
cd worktree-skills-distribution

# Run the installer
./install.sh
```

The installer will:
1. Create `~/.claude/skills/` directory if needed
2. Copy all three skills
3. Set correct permissions
4. Verify installation

### Option 2: Manual Install

```bash
# Create skills directory
mkdir -p ~/.claude/skills

# Copy skills
cp -r worktree ~/.claude/skills/
cp -r worktree-rm ~/.claude/skills/
cp -r worktrees ~/.claude/skills/

# Make scripts executable
chmod +x ~/.claude/skills/worktree/scripts/*.sh
chmod +x ~/.claude/skills/worktree-rm/scripts/*.sh
chmod +x ~/.claude/skills/worktrees/scripts/*.sh

# Restart Claude Code
```

## Usage

### Create a Worktree (`/wt`)

```bash
# Basic usage - new feature branch
/wt my-feature-branch

# New branch from specific base
/wt my-feature develop

# Existing branch or PR
/wt fix-bug-123

# With subdirectory as working directory
/wt api-changes main ./apps/server
```

**What it does:**
1. Creates git worktree in `../{repo}-wt/{branch}/`
2. Picks contextual emoji based on branch name
3. Runs `pnpm install`
4. Copies/configures env files
5. Sets up git exclude patterns
6. Creates VSCode tasks (s/c/t)
7. Adds to VSCode workspace
8. Tracks with Graphite (if available)
9. Copies resume command to clipboard

**Output:**
```
┌─────────────────────────────────────────────────────────────────┐
│  WORKTREE CREATED ✅                                            │
├─────────────────────────────────────────────────────────────────┤
│  Location:  /Users/you/project-wt/my-feature                    │
│  Branch:    my-feature [NEW from main]                          │
├─────────────────────────────────────────────────────────────────┤
│  Dependencies:  ✅ installed                                     │
│  VSCode:        🌳✨ my-feature                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Remove a Worktree (`/wt-rm`)

```bash
# Remove worktree safely
/wt-rm my-feature-branch
```

**Safety checks:**
- Warns about uncommitted changes
- Checks if branch is merged
- Confirms before deletion
- Removes from VSCode workspace
- Cleans git metadata

### View Worktree Status (`/wts`)

```bash
# Show dashboard
/wts
```

**Output:**
```
Project: my-project
┌────────────┬─────────────────┬──────────┬─────────────┐
│ Worktree   │ Branch          │ Changes  │ PR Status   │
├────────────┼─────────────────┼──────────┼─────────────┤
│ my-feature │ my-feature      │ 3 files  │ #42         │
│ bug-fix    │ fix/auth-bug    │ clean    │ merged (#40)│
└────────────┴─────────────────┴──────────┴─────────────┘
```

## How It Works

### Worktree Organization

Your project structure becomes:

```
~/Working Directory/
├── my-project/              # Main repo
│   └── my-project.code-workspace
└── my-project-wt/           # Worktree container
    ├── feature-1/           # Worktree 1
    ├── feature-2/           # Worktree 2
    └── bug-fix/             # Worktree 3
```

### Emoji Selection

The `/wt` skill automatically picks contextual emojis based on your branch name:

- `feat/` or `feature/` → ✨ (sparkles)
- `fix/` or `bug/` → 🐛 (bug)
- `docs/` → 📝 (memo)
- `test/` → 🧪 (test tube)
- `perf/` → ⚡ (zap)
- `refactor/` → ♻️ (recycle)
- And 50+ more patterns!

Already-used emojis are automatically excluded.

### VSCode Integration

Each worktree is added to your workspace file:

```json
{
  "folders": [
    {
      "name": "my-project",
      "path": "."
    },
    {
      "name": "🌳✨ my-feature",
      "path": "../my-project-wt/my-feature"
    }
  ]
}
```

### Tasks Integration

Three VSCode tasks are created in each worktree:

- **s** - Start Claude Code session in worktree
- **c** - Commit changes
- **t** - Run tests

Access via: `Cmd+Shift+P` → Run Task → "s"

## Emoji Palette Reference

The full emoji palette is organized by category:

**Development:**
- Feature: ✨ 🎁 🌟 💫
- Bug Fix: 🐛 🔧 🩹 🛠️
- Refactor: ♻️ 🧹 🧼
- Test: 🧪 🔬 ✅ 🎯
- Performance: ⚡ 🏃 🚄 💨

**Infrastructure:**
- Build/Deploy: 🚀 🏗️ 📦 🎉
- Config: ⚙️ 🔩 🎛️ 🔑
- Security: 🔒 🛡️ 🔐

**Content:**
- Docs: 📝 📚 📖 📄
- UI/Design: 🎨 🖌️ 🎭 🌈

And many more! See `worktree/SKILL.md` for the complete list.

## Workflow Example

```bash
# 1. Check current worktrees
/wts

# 2. Create new feature worktree
/wt add-dark-mode

# 3. Claude creates worktree with 🎨 emoji (design-related)
# Opens in VSCode as "🌳🎨 add-dark-mode"

# 4. Work on the feature...
# (VSCode Task: "s" to start Claude session)

# 5. When done, remove worktree
/wt-rm add-dark-mode
```

## Troubleshooting

### Skill not found

**Problem:** Claude doesn't recognize `/wt` commands
**Solution:** Ensure skills are in `~/.claude/skills/` and restart Claude Code

### Permission denied on scripts

**Problem:** Scripts won't execute
**Solution:**
```bash
chmod +x ~/.claude/skills/*/scripts/*.sh
```

### Emoji conflicts

**Problem:** Same emoji used for multiple worktrees
**Solution:** The skill automatically picks the next available emoji. If you want to manually change it, edit the workspace file.

### Git worktree list doesn't show worktrees

**Problem:** Created worktrees manually, not showing up
**Solution:**
```bash
git worktree prune  # Clean stale metadata
/wts                # Should show working worktrees
```

### Workspace file not updated

**Problem:** New worktree not in VSCode workspace
**Solution:** Check that `{project}.code-workspace` exists in repo root. Create one if missing:
```json
{
  "folders": [
    {
      "name": "project-name",
      "path": "."
    }
  ]
}
```

## Customization

### Change Worktree Location

Edit `~/.claude/skills/worktree/scripts/create-worktree.sh`:

```bash
# Default: ../{project}-wt/{branch}
WORKTREE_DIR="$(dirname "$PROJECT_ROOT")/${PROJECT_NAME}-wt/${BRANCH_NAME}"

# Custom: ~/worktrees/{branch}
WORKTREE_DIR="$HOME/worktrees/${BRANCH_NAME}"
```

### Add Custom Emoji Mappings

Edit the emoji palette in `worktree/SKILL.md` to add your own patterns.

### Modify Auto-Setup

Edit the script to customize what happens after worktree creation:
- Skip `pnpm install`
- Add custom initialization scripts
- Configure different env file patterns

## Advanced: Subdirectory Working Directory

If your repo is a monorepo, you can set a subdirectory as the working directory:

```bash
# Create worktree but work in apps/api/
/wt api-feature main ./apps/api
```

This sets:
- Git worktree: `../project-wt/api-feature/` (full repo)
- Claude working directory: `../project-wt/api-feature/apps/api/` (focused)
- VSCode opens to the full repo but tasks run in subdirectory

## FAQ

**Q: Can I use this with npm or yarn?**
A: Yes, edit the scripts and replace `pnpm install` with `npm install` or `yarn install`.

**Q: Do I need Graphite?**
A: No, it's optional. The skill checks if `gt` is available and skips if not.

**Q: Can I use this outside Claude Code?**
A: The scripts are standalone bash scripts. You can run them directly:
```bash
~/.claude/skills/worktree/scripts/create-worktree.sh my-branch main ✨
```

**Q: What happens to my worktrees if I uninstall?**
A: Git worktrees persist independently. You can manage them with standard git commands:
```bash
git worktree list
git worktree remove {path}
```

## Contributing

Found a bug or want to add features? These skills are part of the [Shipyard](https://github.com/SchoolAI/shipyard) project.

## Credits

Created for the Shipyard project by [@jacobpetterle](https://github.com/jacobpetterle).

## License

MIT - Use freely!
