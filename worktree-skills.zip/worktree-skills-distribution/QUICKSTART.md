# Quick Start Guide

Get up and running with git worktree skills in 2 minutes!

## Install

```bash
# Extract and install
unzip worktree-skills.zip
cd worktree-skills-distribution
./install.sh

# Restart Claude Code
```

## Verify Installation

```bash
# In Claude Code, navigate to any git repo and run:
/wts
```

You should see a worktree status dashboard (even if empty).

## Your First Worktree

```bash
# Create a new feature branch worktree
/wt my-first-feature
```

Claude will:
1. ✨ Pick an emoji based on "feature" → ✨ (sparkles)
2. 📁 Create worktree in `../your-repo-wt/my-first-feature/`
3. 📦 Run `pnpm install`
4. 🔧 Configure env files, git exclude, VSCode tasks
5. 📋 Add to VSCode workspace as "🌳✨ my-first-feature"
6. 📋 Copy resume command to clipboard

## Work in the Worktree

**Option A: Via VSCode Tasks (Recommended)**
1. Press `Cmd+Shift+P` (macOS) or `Ctrl+Shift+P` (Windows/Linux)
2. Type "Run Task"
3. Select "s" (start session)
4. Claude session starts in the worktree!

**Option B: Via Clipboard**
1. Open new terminal
2. Paste (resume command was copied)
3. Hit Enter

## Check Status Anytime

```bash
/wts
```

Shows all worktrees with:
- Branch name
- Uncommitted changes count
- PR status (if using `gh` CLI)

## Clean Up When Done

```bash
/wt-rm my-first-feature
```

Safely removes the worktree with:
- ⚠️ Warnings for uncommitted changes
- ✅ Merge status check
- 🗑️ Workspace cleanup

## Common Workflows

### Feature Development
```bash
/wt new-feature              # Create
# ... work on feature ...
/wt-rm new-feature           # Remove when merged
```

### Bug Fix from Specific Base
```bash
/wt hotfix-123 production    # Create from production branch
# ... fix bug ...
/wt-rm hotfix-123            # Remove
```

### Working on Existing PR
```bash
/wt feature-branch           # Opens existing branch
# ... make changes ...
```

### Monorepo: Work in Subdirectory
```bash
/wt api-change main ./apps/api
# Worktree created for full repo
# But Claude works in apps/api/ only
```

## Tips

🎯 **Emoji Auto-Selection**: Branch names like `feat/`, `fix/`, `docs/` get contextual emojis automatically

📁 **Organization**: All worktrees go in `../{repo}-wt/` - keeps your main repo clean

🔄 **Multiple Worktrees**: Create as many as you need - work on multiple features simultaneously

📊 **Dashboard**: Run `/wts` frequently to see what's active

🧹 **Cleanup**: `/wt-rm` is safe - it warns before destructive operations

## Troubleshooting

**Skill not found?**
- Restart Claude Code
- Check `~/.claude/skills/` has `worktree/`, `worktree-rm/`, `worktrees/`

**Permission denied?**
- Run: `chmod +x ~/.claude/skills/*/scripts/*.sh`

**Want to customize?**
- Edit scripts in `~/.claude/skills/worktree/scripts/`
- See README.md for customization guide

## Full Documentation

See `README.md` for:
- Complete emoji palette
- Advanced customization
- FAQ
- Troubleshooting guide

Happy worktree-ing! 🌳
