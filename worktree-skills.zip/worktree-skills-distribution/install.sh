#!/bin/bash
# Git Worktree Skills Installer for Claude Code
# Installs /wt, /wt-rm, and /wts skills

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Installation directory
SKILLS_DIR="$HOME/.claude/skills"

echo ""
echo "┌─────────────────────────────────────────────────────────────────┐"
echo "│  Git Worktree Skills Installer                                 │"
echo "│  Installing: /wt, /wt-rm, /wts                                  │"
echo "└─────────────────────────────────────────────────────────────────┘"
echo ""

# Check prerequisites
echo -e "${BLUE}Checking prerequisites...${NC}"

# Check for required commands
missing_deps=()

if ! command -v git &> /dev/null; then
    missing_deps+=("git")
fi

if ! command -v pnpm &> /dev/null; then
    echo -e "${YELLOW}⚠️  pnpm not found - scripts will need modification for npm/yarn${NC}"
fi

if ! command -v gh &> /dev/null; then
    echo -e "${YELLOW}⚠️  gh CLI not found - PR status will not work in /wts${NC}"
fi

if ! command -v jq &> /dev/null; then
    missing_deps+=("jq")
fi

if [ ${#missing_deps[@]} -ne 0 ]; then
    echo -e "${RED}✗ Missing required dependencies: ${missing_deps[*]}${NC}"
    echo ""
    echo "Install missing dependencies:"
    echo "  macOS: brew install ${missing_deps[*]}"
    echo "  Ubuntu: sudo apt-get install ${missing_deps[*]}"
    exit 1
fi

echo -e "${GREEN}✓ All required dependencies found${NC}"
echo ""

# Create skills directory
echo -e "${BLUE}Creating skills directory...${NC}"
mkdir -p "$SKILLS_DIR"
echo -e "${GREEN}✓ $SKILLS_DIR${NC}"
echo ""

# Install each skill
for skill in worktree worktree-rm worktrees; do
    echo -e "${BLUE}Installing ${skill}...${NC}"

    # Remove existing if present
    if [ -d "$SKILLS_DIR/$skill" ]; then
        echo -e "${YELLOW}  Removing existing ${skill}${NC}"
        rm -rf "$SKILLS_DIR/$skill"
    fi

    # Copy skill
    cp -r "$skill" "$SKILLS_DIR/"

    # Make scripts executable
    if [ -d "$SKILLS_DIR/$skill/scripts" ]; then
        chmod +x "$SKILLS_DIR/$skill/scripts"/*.sh
        echo -e "${GREEN}  ✓ Installed and made scripts executable${NC}"
    else
        echo -e "${GREEN}  ✓ Installed${NC}"
    fi
done

echo ""
echo "┌─────────────────────────────────────────────────────────────────┐"
echo "│  ✅ Installation Complete!                                      │"
echo "└─────────────────────────────────────────────────────────────────┘"
echo ""
echo -e "${BLUE}Installed Skills:${NC}"
echo "  • /wt       - Create worktree with emoji tagging"
echo "  • /wt-rm    - Remove worktree safely"
echo "  • /wts      - Show worktree status dashboard"
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo "  1. Restart Claude Code (if running)"
echo "  2. Navigate to a git repository"
echo "  3. Try: /wts (show current worktrees)"
echo "  4. Try: /wt my-feature (create new worktree)"
echo ""
echo -e "${BLUE}Usage Examples:${NC}"
echo "  /wt my-feature              # New feature branch"
echo "  /wt fix-bug main            # New branch from main"
echo "  /wt existing-pr             # Existing branch/PR"
echo "  /wts                        # Show dashboard"
echo "  /wt-rm my-feature           # Remove worktree"
echo ""
echo -e "${GREEN}Read README.md for full documentation!${NC}"
echo ""
