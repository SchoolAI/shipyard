---
name: worktrees
description: Show status dashboard of all git worktrees. Use when user wants to see worktree status, list worktrees, or check PR status.
model: claude-haiku-4-5-20251001
allowed-tools: Bash(*)
---

# Worktree Status Dashboard

Run the status script and display its output:

```bash
~/.claude/skills/worktrees/scripts/list-worktrees.sh
```

The script outputs a formatted ASCII table showing all worktrees with their branch, change count, and PR status.

Simply display the script output to the user.
