#!/bin/bash

# List all git worktrees with status
# Output: Formatted ASCII dashboard
#
# Generic - works from any git repository

# Auto-detect project root
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null)
if [[ -z "$PROJECT_ROOT" ]]; then
    echo "Error: Not in a git repository"
    exit 1
fi

PROJECT_NAME=$(basename "$PROJECT_ROOT")

# Collect worktree data
declare -a WORKTREES
declare -a BRANCHES
declare -a CHANGES
declare -a PR_STATUSES

# Get worktree list using porcelain format for reliable parsing
while IFS= read -r line; do
    if [[ "$line" =~ ^worktree\ (.*) ]]; then
        WORKTREE_PATH="${BASH_REMATCH[1]}"
    elif [[ "$line" =~ ^branch\ refs/heads/(.*) ]]; then
        BRANCH="${BASH_REMATCH[1]}"
    elif [[ "$line" == "" && -n "$WORKTREE_PATH" ]]; then
        # End of worktree entry, process it

        # Skip the main worktree (the project root itself)
        if [[ "$WORKTREE_PATH" == "$PROJECT_ROOT" ]]; then
            WORKTREE_PATH=""
            BRANCH=""
            continue
        fi

        # Get short name for display
        WORKTREE_NAME=$(basename "$WORKTREE_PATH")

        # Count changes
        if [[ -d "$WORKTREE_PATH" ]]; then
            cd "$WORKTREE_PATH" 2>/dev/null || continue
            CHANGE_COUNT=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
            if [[ "$CHANGE_COUNT" -eq 0 ]]; then
                CHANGE_STATUS="clean"
            else
                CHANGE_STATUS="${CHANGE_COUNT} files"
            fi

            # Get PR status via GitHub CLI
            GH_PR=$(gh pr list --state all --head "$BRANCH" --json number,state 2>/dev/null | jq -r '.[0] // empty')
            if [[ -n "$GH_PR" ]]; then
                GH_STATE=$(echo "$GH_PR" | jq -r '.state')
                GH_NUM=$(echo "$GH_PR" | jq -r '.number')
                if [[ "$GH_STATE" == "MERGED" ]]; then
                    PR_STATUS="merged (#$GH_NUM)"
                elif [[ "$GH_STATE" == "OPEN" ]]; then
                    PR_STATUS="#$GH_NUM"
                else
                    PR_STATUS="$GH_STATE"
                fi
            else
                PR_STATUS="not submitted"
            fi
        else
            CHANGE_STATUS="?"
            PR_STATUS="?"
        fi

        WORKTREES+=("$WORKTREE_NAME")
        BRANCHES+=("$BRANCH")
        CHANGES+=("$CHANGE_STATUS")
        PR_STATUSES+=("$PR_STATUS")

        # Reset for next entry
        WORKTREE_PATH=""
        BRANCH=""
    fi
done < <(git worktree list --porcelain 2>/dev/null; echo "")

# Return to project root
cd "$PROJECT_ROOT" 2>/dev/null || true

# Check if we found any worktrees
if [[ ${#WORKTREES[@]} -eq 0 ]]; then
    echo "┌─────────────────────────────────────────────────────────────────────────────────┐"
    echo "│  No worktrees found for: $PROJECT_NAME"
    printf "│  %-79s│\n" ""
    echo "│  Create one with: /wt <branch-name> [base]                                      │"
    echo "└─────────────────────────────────────────────────────────────────────────────────┘"
    exit 0
fi

# Calculate column widths
MAX_WT=20
MAX_BR=25
MAX_CH=10
MAX_PR=20

for i in "${!WORKTREES[@]}"; do
    [[ ${#WORKTREES[$i]} -gt $MAX_WT ]] && MAX_WT=${#WORKTREES[$i]}
    [[ ${#BRANCHES[$i]} -gt $MAX_BR ]] && MAX_BR=${#BRANCHES[$i]}
    [[ ${#CHANGES[$i]} -gt $MAX_CH ]] && MAX_CH=${#CHANGES[$i]}
    [[ ${#PR_STATUSES[$i]} -gt $MAX_PR ]] && MAX_PR=${#PR_STATUSES[$i]}
done

# Cap column widths
[[ $MAX_WT -gt 25 ]] && MAX_WT=25
[[ $MAX_BR -gt 30 ]] && MAX_BR=30
[[ $MAX_CH -gt 12 ]] && MAX_CH=12
[[ $MAX_PR -gt 22 ]] && MAX_PR=22

# Helper: print horizontal line
print_line() {
    local char="$1"
    local left="$2"
    local right="$3"
    local sep="$4"
    printf "%s" "$left"
    printf "%s" "$(printf '%*s' $((MAX_WT + 2)) '' | tr ' ' "$char")"
    printf "%s" "$sep"
    printf "%s" "$(printf '%*s' $((MAX_BR + 2)) '' | tr ' ' "$char")"
    printf "%s" "$sep"
    printf "%s" "$(printf '%*s' $((MAX_CH + 2)) '' | tr ' ' "$char")"
    printf "%s" "$sep"
    printf "%s" "$(printf '%*s' $((MAX_PR + 2)) '' | tr ' ' "$char")"
    printf "%s\n" "$right"
}

# Helper: print row
print_row() {
    printf "│ %-${MAX_WT}s │ %-${MAX_BR}s │ %-${MAX_CH}s │ %-${MAX_PR}s │\n" \
        "${1:0:$MAX_WT}" "${2:0:$MAX_BR}" "${3:0:$MAX_CH}" "${4:0:$MAX_PR}"
}

# Print header
echo ""
echo "Project: $PROJECT_NAME"
print_line "─" "┌" "┐" "┬"
printf "│ %-${MAX_WT}s │ %-${MAX_BR}s │ %-${MAX_CH}s │ %-${MAX_PR}s │\n" \
    "Worktree" "Branch" "Changes" "PR Status"
print_line "─" "├" "┤" "┼"

# Print rows
for i in "${!WORKTREES[@]}"; do
    print_row "${WORKTREES[$i]}" "${BRANCHES[$i]}" "${CHANGES[$i]}" "${PR_STATUSES[$i]}"
done

# Print footer
print_line "─" "└" "┘" "┴"

# Print quick actions
echo ""
echo "┌─────────────────────────────────────────────────────────────────────────────────┐"
echo "│  QUICK ACTIONS                                                                  │"
echo "├─────────────────────────────────────────────────────────────────────────────────┤"
echo "│  New worktree:    /wt <branch-name> [base]                                      │"
echo "│  Remove worktree: /wt-rm <branch-name>                                          │"
echo "│  Start session:   Cmd+Shift+P → Run Task → \"s\" (in worktree)                   │"
echo "│  Submit PR:       gh pr create (from worktree directory)                        │"
echo "└─────────────────────────────────────────────────────────────────────────────────┘"
